import { defineStore } from 'pinia'
import { teacherV1Api } from '../services/v1'

export const AUTH_TOKEN_KEY = 'fuww_teacher_auth_token'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    isLoggedIn: false,
    username: '',
    userId: '',
    role: '',
    token: '',
    backendStatus: 'checking' // 'online' | 'offline' | 'demo' | 'checking'
  }),

  getters: {
    isTeacher: (state) => state.role === 'teacher',
    isAuthenticated: (state) => state.isLoggedIn && !!state.token
  },

  actions: {
    async login(user) {
      this.isLoggedIn = true
      this.username = user.username || ''
      this.userId = user.userId || ''
      this.role = user.role || 'teacher'
      this.token = user.token || `local_${Date.now()}`

      if (typeof window !== 'undefined') {
        localStorage.setItem('fuww_teacher_logged_in', '1')
        localStorage.setItem('fuww_teacher_username', this.username)
        localStorage.setItem('fuww_teacher_role', this.role)
        if (user.token) localStorage.setItem(AUTH_TOKEN_KEY, user.token)
        else localStorage.removeItem(AUTH_TOKEN_KEY)
      }
    },

    logout() {
      this.isLoggedIn = false
      this.username = ''
      this.userId = ''
      this.role = ''
      this.token = ''

      if (typeof window !== 'undefined') {
        localStorage.removeItem('fuww_teacher_logged_in')
        localStorage.removeItem('fuww_teacher_username')
        localStorage.removeItem('fuww_teacher_role')
        localStorage.removeItem(AUTH_TOKEN_KEY)
      }
    },

    async checkHealth() {
      this.backendStatus = 'checking'
      try {
        const res = await teacherV1Api.health()
        this.backendStatus = res.ok ? 'online' : 'offline'
        if (res.ok && typeof window !== 'undefined') {
          window.localStorage.removeItem('fuww_mock_mode')
        }
      } catch {
        const inDemoMode = typeof window !== 'undefined' && window.localStorage.getItem('fuww_mock_mode') === 'true'
        this.backendStatus = inDemoMode ? 'demo' : 'offline'
      }
    },

    restoreSession() {
      if (typeof window === 'undefined') return false
      const loggedIn = localStorage.getItem('fuww_teacher_logged_in')
      const username = localStorage.getItem('fuww_teacher_username')
      const role = localStorage.getItem('fuww_teacher_role')
      const token = localStorage.getItem(AUTH_TOKEN_KEY)
      if (loggedIn && username) {
        this.isLoggedIn = true
        this.username = username
        this.role = role || 'teacher'
        this.token = token || `local_${Date.now()}`
        return true
      }
      return false
    },

    hydrate() {
      const params = new URLSearchParams(typeof window !== 'undefined' ? window.location.search : '')
      const role = String(params.get('role') || '').trim().toLowerCase()
      const username = String(params.get('username') || '').trim().toLowerCase()

      if (role === 'teacher' && username) {
        this.login({ username, role })
        if (typeof window !== 'undefined') {
          window.history.replaceState({}, document.title, window.location.pathname)
        }
        return true
      }

      return this.restoreSession()
    }
  }
})
