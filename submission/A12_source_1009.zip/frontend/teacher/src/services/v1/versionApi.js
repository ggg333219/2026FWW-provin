import { requestJson } from './request'

/**
 * S4 版本管理 API — 对接 Python 后端 /api/v1/version/{gen_id}/...
 */
export const teacherVersionApi = {
  /**
   * 版本历史列表
   * GET /api/v1/version/{genId}/history
   */
  history: (genId) =>
    requestJson(`/api/v1/version/${encodeURIComponent(genId)}/history`),

  /**
   * 加载指定版本
   * GET /api/v1/version/{genId}?v={versionNumber}
   */
  load: (genId, versionNumber = null) => {
    const query = versionNumber != null ? `?v=${versionNumber}` : ''
    return requestJson(`/api/v1/version/${encodeURIComponent(genId)}${query}`)
  },

  /**
   * 对比两个版本
   * GET /api/v1/version/{genId}/diff?v1=1&v2=2
   */
  diff: (genId, v1, v2) =>
    requestJson(`/api/v1/version/${encodeURIComponent(genId)}/diff?v1=${v1}&v2=${v2}`),

  /**
   * 回滚到指定版本
   * POST /api/v1/version/{genId}/rollback
   */
  rollback: (genId, targetVersion) =>
    requestJson(`/api/v1/version/${encodeURIComponent(genId)}/rollback`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ target_version: targetVersion })
    }),

  /**
   * 锁定当前版本
   * POST /api/v1/version/{genId}/lock
   */
  lock: (genId) =>
    requestJson(`/api/v1/version/${encodeURIComponent(genId)}/lock`, {
      method: 'POST'
    }),

  /**
   * 创建导出任务
   * POST /api/v1/exp/{genId}（/export 保留为后端兼容别名）
   */
  exportCreate: (genId, format = 'pptx', version = null, coursewareTitle = '', nodes = [], projectId = '', generationInstructionSet = {}, presentation = {}) =>
    requestJson(`/api/v1/exp/${encodeURIComponent(genId)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        format,
        version: version || null,
        courseware_title: coursewareTitle || '',
        nodes: Array.isArray(nodes) ? nodes : [],
        project_id: projectId || '',
        presentation: presentation || {},
        generation_instruction_set: generationInstructionSet || {}
      })
    }),

  /**
   * 查询导出任务状态
   * GET /api/v1/exp/status/{jobId}
   */
  exportStatus: (jobId) =>
    requestJson(`/api/v1/exp/status/${encodeURIComponent(jobId)}`),

  /**
   * 提交修改命令
   * POST /api/v1/gen/modify
   * @param {string} genId - generation ID
   * @param {Array} commands - 修改命令列表 [{type, node_id, content, ...}]
   */
  modify: (genId, commands) =>
    requestJson('/api/v1/gen/modify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ generation_id: genId, commands })
    })
}
