# 教师端前端（开发者说明）

本文面向教师端前端开发者。评委运行完整系统请从仓库根目录按 [README](../../README.md) 操作；单独运行此子应用时，需要另外启动后端和 AI Engine。

## 开发说明

- 默认接口基址见 [src/config/api.js](src/config/api.js)
- 教师端业务接口主要由 `src/services/v1/` 封装；本地开发时请确认 API 代理和后端地址与当前运行环境一致。

## 常用命令

- `npm install`
- `npm run dev`
- `npm run build`

根目录 `scripts/start-all.ps1` 会统一启动教师端及其后端依赖；独立运行 `npm run dev` 仅启动前端开发服务器。
