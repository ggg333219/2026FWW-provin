# 本地服务脚本（维护者说明）

本文面向需要分别启停本地服务的开发者和维护者。评委首次运行步骤请看仓库根目录的 [README](../README.md)。

## 脚本职责

- `start-all.ps1`：读取仓库根目录 `.env`，启动 Docker 基础服务、AI Engine、Go 教师端后端和 Vite 前端；若前端依赖未安装，会尝试安装依赖。后台进程信息写入 `scripts/pids.json`，日志写入 `logs/`。
- `stop-all.ps1`：停止脚本记录的后台进程，并默认停止 Compose 服务。传入 `-SkipDocker` 可保留基础服务容器。
- 启动脚本的 `-SkipDocker`：适用于 PostgreSQL、Redis、MinIO 已由其他方式启动的环境。

## 使用

在仓库根目录的 PowerShell 中执行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\start-all.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\stop-all.ps1
```

若基础服务已就绪，可在启动命令后添加 `-SkipDocker`。若要停止应用但保留基础服务容器，在停止命令后添加 `-SkipDocker`。

## 环境与诊断

需要 Docker Desktop、Go、Node.js/npm 和 Python 环境。AI Engine 可使用脚本配置的 Python/Conda 环境；如启动失败，先检查 `logs/` 中对应服务的标准输出和错误日志。端口冲突时以启动脚本报告的实际端口及 `backend/.runtime/teacher.json` 为准。
