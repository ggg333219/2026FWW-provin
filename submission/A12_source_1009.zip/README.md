# 多模态 AI 互动式教学智能体（A12）

## 项目简介

本项目面向教师备课，提供从教学需求到课件交付的工作流：教师描述教学目标，系统解析参考资料并检索知识库，生成大纲和教学内容，再通过预览、编辑、版本管理导出 PPTX、Word 教案或 HTML5 互动内容。

系统由 Vue 3 教师端、Go 业务后端和 Python AI Engine 组成；PostgreSQL（含 pgvector）、Redis、MinIO 由 Docker Compose 提供。

## 运行环境

- Windows 10/11
- Go 1.25.1、Node.js 20.19+、Python 3.10+
- Docker Desktop（运行 PostgreSQL、Redis、MinIO）
- 可访问的 OpenAI 兼容模型服务及其 API Key

首次运行前，请在 Docker Desktop 中启动 Docker Engine，并在仓库根目录准备运行配置：

```powershell
Copy-Item .env.example .env
```

编辑 `.env`，配置可用的模型服务地址、模型名称和 API Key（参照其中的 `AI_BASE_URL`、`AI_MODEL`、`AI_API_KEY` 字段）。本项目启动脚本会读取根目录 `.env` 并将配置传给 AI Engine；请勿只把密钥放在 `.env.local`。请使用自己有权访问的模型服务；未配置有效凭据时，真实 AI 生成、意图解析和证据融合可能不可用或退回本地兜底。密钥只保存在本机配置文件中，不要粘贴到 README 或界面截图中。

首次启动前还需安装项目依赖：

```powershell
python -m pip install -r ai_engine/requirements.txt
Set-Location frontend/teacher
npm.cmd ci
Set-Location ../..
```

## 启动与访问

在仓库根目录运行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\start-all.ps1
```

启动脚本会读取根目录 `.env`，启动 Docker 基础服务、AI Engine、Go 教师端后端和教师端前端，并执行健康检查。服务就绪后访问：

- 教师端：<http://localhost:5173>
- AI Engine 健康检查：<http://localhost:8000/health>
- Go 后端健康检查：通常为 <http://localhost:8082/health>

如果后端默认端口已被占用，启动脚本可能选择其他端口；请以终端输出、`logs/` 日志及 `backend/.runtime/teacher.json` 中记录的实际地址为准。若 PostgreSQL、Redis、MinIO 已在本机单独运行，可用 `-SkipDocker` 跳过 Compose 启动：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\start-all.ps1 -SkipDocker
```

结束演示时，在仓库根目录运行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\stop-all.ps1
```

如需保留数据库等 Docker 容器，可给停止脚本添加 `-SkipDocker`。

## 建议演示与验收流程

1. 在教师端创建教学任务，输入课程主题、对象和课时等需求，检查意图理解结果。
2. 在 S2 上传参考材料并等待解析完成。解析出的切片会自动索引到当前配置的知识库，并刷新供大纲/内容生成使用的证据包；可检查自动检索结果是否与上传资料相关。这是“上传资料后自动索引”，不是应用启动时自动导入一套固定知识库资料。索引是否跨重启保留，取决于当前向量存储配置。
3. 生成大纲和教学内容，查看节点内容及教师讲稿；尝试手工编辑或通过 AI 指令修改，再确认修改已保存。
4. 在 S4 预览并检查页面顺序、版本记录和导出选项；导出 PPTX、Word 教案或 HTML5 互动内容后打开文件检查实际内容。

AI 调用和文档导出需要模型服务及基础设施正常工作。建议演示时确认浏览器当前使用的是本次启动的教师端，并留意页面是否提示 Mock、本地兜底或 AI 服务错误；出现此类提示时，生成结果不一定来自实时模型。

## 故障排查

- 查看 `logs/ai_engine.log`、`logs/ai_engine.err.log`、`logs/backend.log` 和 `logs/teacher_frontend.log`。
- 检查基础服务：

  ```powershell
  docker compose -f backend/docker-compose.yml ps
  ```

- 若页面无法访问，先检查启动脚本输出的实际端口；如果端口被旧进程占用，使用 `scripts/stop-all.ps1` 停止本项目进程后再启动。
- 模型调用失败时，检查 `.env` 中的模型服务地址、模型名称、API Key 和网络连通性。

## 项目目录

- `frontend/teacher/`：Vue 3 + Vite 教师端
- `backend/`：Go API 后端及 Docker Compose 基础服务
- `ai_engine/`：FastAPI AI Engine、知识检索及内容生成
- `scripts/`：本地服务启停和辅助脚本
