package service

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

// ---- fake AIEngine：仅实现大纲两个方法，其余留空（测试只走 OutlineService）----

type fakeOutlineAI struct {
	generateResp *OutlineGenerateResponse
	reviseResp   *OutlineReviseAIResponse
	generateErr  error
	reviseErr    error
}

func (f *fakeOutlineAI) GenerateOutline(_ context.Context, _ OutlineGenerateRequest) (*OutlineGenerateResponse, error) {
	if f.generateErr != nil {
		return nil, f.generateErr
	}
	return f.generateResp, nil
}

func (f *fakeOutlineAI) ReviseOutline(_ context.Context, _ OutlineReviseAIRequest) (*OutlineReviseAIResponse, error) {
	if f.reviseErr != nil {
		return nil, f.reviseErr
	}
	return f.reviseResp, nil
}

func sampleNodes() []OutlineNode {
	return []OutlineNode{
		{NodeID: "node_001", Order: 1, Title: "引言", Summary: "课程导入", NodeType: OutlineNodeTypeContent, KeyPoints: []string{"背景"}, EstimatedDurationMin: 5},
		{NodeID: "node_002", Order: 2, Title: "主算法", Summary: "核心讲解", NodeType: OutlineNodeTypeSection, KeyPoints: []string{"原理"}, EstimatedDurationMin: 20},
	}
}

func TestOutlineRequestsUseExtendedTimeoutWithoutChangingOtherCalls(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		time.Sleep(80 * time.Millisecond)
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"nodes":[]}`))
	}))
	defer server.Close()

	client := NewAIEngineClient(server.URL, 20*time.Millisecond).(*aiEngineClient)
	if _, err := client.GenerateOutline(context.Background(), OutlineGenerateRequest{}); err != nil {
		t.Fatalf("大纲请求未使用专用等待时间: %v", err)
	}
	var response map[string]any
	if err := client.postJSON(context.Background(), "/other", map[string]any{}, &response); err == nil {
		t.Fatal("普通 AI 请求不应继承大纲专用等待时间")
	}
}

func TestOutlineFallbackMetadataPersistenceRoundTrip(t *testing.T) {
	original := &Outline{
		OutlineID: "outline_fallback", OutlineVersion: 1,
		UsedFallback: true, FallbackReason: "timeout", Nodes: sampleNodes(),
	}
	row, err := marshalOutlineRow(original)
	if err != nil {
		t.Fatal(err)
	}
	restored, err := unmarshalOutlineRow(row)
	if err != nil {
		t.Fatal(err)
	}
	if !restored.UsedFallback || restored.FallbackReason != "timeout" {
		t.Fatalf("回退元数据未在持久化序列化中保留: %+v", restored)
	}
}

func TestNormalizeOutlineFallbackReasonOnlyReturnsSafeCategories(t *testing.T) {
	if got := normalizeOutlineFallbackReason(true, "timeout: secret detail"); got != "model_error" {
		t.Fatalf("不安全的回退原因未归一: %q", got)
	}
	if got := normalizeOutlineFallbackReason(false, "timeout"); got != "" {
		t.Fatalf("AI 成功结果不应带回退原因: %q", got)
	}
}

func newTestService() *OutlineService {
	return &OutlineService{
		aiClient: &fakeOutlineAI{
			generateResp: &OutlineGenerateResponse{Nodes: sampleNodes()},
			reviseResp:   &OutlineReviseAIResponse{Nodes: sampleNodes(), ChangeSummary: []string{"调整顺序"}},
		},
		store: newMemOutlineStore(),
	}
}

func mustCreateOutline(t *testing.T, svc *OutlineService, sessionID string) *Outline {
	t.Helper()
	outline, err := svc.CreateOutline(context.Background(), OutlineGenerateRequest{
		SessionID: sessionID,
		Intent:    &IntentSummary{},
	})
	if err != nil {
		t.Fatalf("CreateOutline 失败: %v", err)
	}
	if outline.OutlineID == "" {
		t.Fatal("CreateOutline 未生成 outline_id")
	}
	if outline.OutlineVersion != 1 {
		t.Fatalf("首版应为 version=1, 实际 %d", outline.OutlineVersion)
	}
	if outline.Status != OutlineStatusDraft {
		t.Fatalf("首版应为 draft, 实际 %s", outline.Status)
	}
	return outline
}

// TestCreateOutlineVersion1Draft —— 创建大纲 → version=1 + status=draft。
func TestCreateOutlineVersion1Draft(t *testing.T) {
	svc := newTestService()
	outline := mustCreateOutline(t, svc, "session_1")
	if len(outline.Nodes) != 2 {
		t.Fatalf("节点数应为 2, 实际 %d", len(outline.Nodes))
	}
	if outline.Nodes[0].Order != 1 || outline.Nodes[1].Order != 2 {
		t.Fatalf("order 应重排为连续 1..n: %v", []int{outline.Nodes[0].Order, outline.Nodes[1].Order})
	}
}

// TestConfirmFlow —— draft → confirmed：Confirm 后状态翻转、confirmed_at 非空。
func TestConfirmFlow(t *testing.T) {
	svc := newTestService()
	outline := mustCreateOutline(t, svc, "session_1")

	confirmed, err := svc.ConfirmOutline(context.Background(), outline.OutlineID, 1)
	if err != nil {
		t.Fatalf("ConfirmOutline 失败: %v", err)
	}
	if confirmed.Status != OutlineStatusConfirmed {
		t.Fatalf("确认后应为 confirmed, 实际 %s", confirmed.Status)
	}
	if confirmed.ConfirmedAt == nil {
		t.Fatal("确认后 confirmed_at 不应为空")
	}

	// 已确认大纲可被 GetConfirmed 读取（供 GenerationHandler 注入节点）
	got, err := svc.GetConfirmed(context.Background(), outline.OutlineID, 1)
	if err != nil {
		t.Fatalf("GetConfirmed 应通过: %v", err)
	}
	if len(got.Nodes) != 2 {
		t.Fatalf("GetConfirmed 应返回节点, 实际 %d", len(got.Nodes))
	}
}

// TestGetConfirmedRejectsDraft —— 未确认大纲 GetConfirmed 必须拒绝（409 语义）。
func TestGetConfirmedRejectsDraft(t *testing.T) {
	svc := newTestService()
	outline := mustCreateOutline(t, svc, "session_1")

	_, err := svc.GetConfirmed(context.Background(), outline.OutlineID, 1)
	if !errors.Is(err, ErrOutlineNotConfirmed) {
		t.Fatalf("未确认大纲应返回 ErrOutlineNotConfirmed, 实际 %v", err)
	}
}

// TestCreateOutlineEmptyNodesRejected —— 空节点大纲创建必须失败（HIGH-3：坏节点不进版本链）。
func TestCreateOutlineEmptyNodesRejected(t *testing.T) {
	svc := newTestService()
	svc.aiClient = &fakeOutlineAI{generateResp: &OutlineGenerateResponse{Nodes: []OutlineNode{}}}
	_, err := svc.CreateOutline(context.Background(), OutlineGenerateRequest{SessionID: "session_1"})
	if !errors.Is(err, ErrInvalidOutline) {
		t.Fatalf("空节点创建应返回 ErrInvalidOutline, 实际 %v", err)
	}
}

// TestSaveVersionConflict —— base_version 不匹配当前版本 → ErrOutlineVersionConflict（409）。
func TestSaveVersionConflict(t *testing.T) {
	svc := newTestService()
	outline := mustCreateOutline(t, svc, "session_1")

	// 以错误 base_version=2 保存（当前为 1）→ 冲突
	_, err := svc.SaveOutlineVersion(context.Background(), outline.OutlineID, 2, sampleNodes())
	if !errors.Is(err, ErrOutlineVersionConflict) {
		t.Fatalf("base_version 不匹配应返回 ErrOutlineVersionConflict, 实际 %v", err)
	}
}

// TestSaveVersionSupersedesConfirmed —— 确认后修改：旧版本 → superseded，新版本 → draft。
func TestSaveVersionSupersedesConfirmed(t *testing.T) {
	svc := newTestService()
	outline := mustCreateOutline(t, svc, "session_1")

	if _, err := svc.ConfirmOutline(context.Background(), outline.OutlineID, 1); err != nil {
		t.Fatalf("ConfirmOutline 失败: %v", err)
	}

	// 对 confirmed v1 保存修改 → 生成 v2(draft)，v1 变 superseded
	nodes := sampleNodes()
	nodes[0].Title = "引言（修订）"
	saved, err := svc.SaveOutlineVersion(context.Background(), outline.OutlineID, 1, nodes)
	if err != nil {
		t.Fatalf("SaveOutlineVersion 失败: %v", err)
	}
	if saved.OutlineVersion != 2 {
		t.Fatalf("修改后应生成 version=2, 实际 %d", saved.OutlineVersion)
	}
	if saved.Status != OutlineStatusDraft {
		t.Fatalf("新版本应为 draft（可重新确认）, 实际 %s", saved.Status)
	}

	old, err := svc.GetOutline(context.Background(), outline.OutlineID, 1)
	if err != nil {
		t.Fatalf("读取 v1 失败: %v", err)
	}
	if old.Status != OutlineStatusSuperseded {
		t.Fatalf("被修改的 confirmed v1 应置 superseded, 实际 %s", old.Status)
	}
}

// TestSaveVersionDuplicateNodeIDRejected —— node_id 重复 → ErrInvalidOutline（规范 §3.4）。
func TestSaveVersionDuplicateNodeIDRejected(t *testing.T) {
	svc := newTestService()
	outline := mustCreateOutline(t, svc, "session_1")

	dup := []OutlineNode{
		{NodeID: "node_x", Order: 1, Title: "A", Summary: "s", NodeType: OutlineNodeTypeContent, EstimatedDurationMin: 5},
		{NodeID: "node_x", Order: 2, Title: "B", Summary: "s", NodeType: OutlineNodeTypeContent, EstimatedDurationMin: 5},
	}
	_, err := svc.SaveOutlineVersion(context.Background(), outline.OutlineID, 1, dup)
	if !errors.Is(err, ErrInvalidOutline) {
		t.Fatalf("node_id 重复应返回 ErrInvalidOutline, 实际 %v", err)
	}
}

// TestSaveVersionOrderGapRejected —— order 不连续 → ErrInvalidOutline（规范 §3.4）。
func TestSaveVersionOrderGapRejected(t *testing.T) {
	svc := newTestService()
	outline := mustCreateOutline(t, svc, "session_1")

	gap := []OutlineNode{
		{NodeID: "node_a", Order: 1, Title: "A", Summary: "s", NodeType: OutlineNodeTypeContent, EstimatedDurationMin: 5},
		{NodeID: "node_b", Order: 3, Title: "B", Summary: "s", NodeType: OutlineNodeTypeContent, EstimatedDurationMin: 5}, // order 跳号
	}
	_, err := svc.SaveOutlineVersion(context.Background(), outline.OutlineID, 1, gap)
	if !errors.Is(err, ErrInvalidOutline) {
		t.Fatalf("order 不连续应返回 ErrInvalidOutline, 实际 %v", err)
	}
}

// TestReviseCandidatePersists —— 修订候选(auto_apply=false)落库为 v2 draft。
// 修复 HIGH-1：候选不落库会导致前端 applyRevision 采纳后本地版本号与后端链脱节，
// 后续 save(base_version=候选号)→409 / confirm(候选号)→404。候选必须持久化。
func TestReviseCandidatePersists(t *testing.T) {
	svc := newTestService()
	outline := mustCreateOutline(t, svc, "session_1")

	candidate, err := svc.ReviseOutline(context.Background(), outline.OutlineID, "加个例子", 1, false)
	if err != nil {
		t.Fatalf("ReviseOutline 失败: %v", err)
	}
	if candidate.OutlineVersion != 2 {
		t.Fatalf("修订候选应预置 version=2, 实际 %d", candidate.OutlineVersion)
	}
	if candidate.Status != OutlineStatusDraft {
		t.Fatalf("修订候选应为 draft, 实际 %s", candidate.Status)
	}

	// 候选已落库：链上最新为 v2，前端 applyRevision 采纳后 save/confirm 可用
	latest, err := svc.GetOutline(context.Background(), outline.OutlineID, 0)
	if err != nil {
		t.Fatal(err)
	}
	if latest.OutlineVersion != 2 {
		t.Fatalf("修订候选应落库为 v2, 实际 %d", latest.OutlineVersion)
	}

	// 采纳路径闭合：确认候选 v2 成功（修复前 → 404）
	confirmed, err := svc.ConfirmOutline(context.Background(), outline.OutlineID, 2)
	if err != nil {
		t.Fatalf("采纳修订后确认候选 v2 应成功, 实际 %v", err)
	}
	if confirmed.Status != OutlineStatusConfirmed {
		t.Fatalf("候选 v2 确认后应为 confirmed, 实际 %s", confirmed.Status)
	}
}

// TestReviseAutoApplyTruePersists —— auto_apply=true：修订结果作为新版本保存。
func TestReviseAutoApplyTruePersists(t *testing.T) {
	svc := newTestService()
	outline := mustCreateOutline(t, svc, "session_1")

	saved, err := svc.ReviseOutline(context.Background(), outline.OutlineID, "加个例子", 1, true)
	if err != nil {
		t.Fatalf("ReviseOutline(auto) 失败: %v", err)
	}
	if saved.OutlineVersion != 2 {
		t.Fatalf("auto_apply=true 应保存为 v2, 实际 %d", saved.OutlineVersion)
	}

	latest, err := svc.GetOutline(context.Background(), outline.OutlineID, 0)
	if err != nil {
		t.Fatal(err)
	}
	if latest.OutlineVersion != 2 {
		t.Fatalf("落库后最新应 v2, 实际 %d", latest.OutlineVersion)
	}
}

// TestCreateOutlineSessionRequired —— 无 session_id 拒绝。
func TestCreateOutlineSessionRequired(t *testing.T) {
	svc := newTestService()
	_, err := svc.CreateOutline(context.Background(), OutlineGenerateRequest{})
	if err == nil {
		t.Fatal("session_id 为空应报错")
	}
}

func TestCreateOutlineFromVersionNodesDoesNotCallAI(t *testing.T) {
	svc := &OutlineService{
		aiClient: &fakeOutlineAI{generateErr: errors.New("AI must not be called for a version fork")},
		store:    newMemOutlineStore(),
	}
	seed := sampleNodes()
	created, err := svc.CreateOutline(context.Background(), OutlineGenerateRequest{
		SessionID: "project_1", CourseName: "排序算法", Nodes: seed,
	})
	if err != nil {
		t.Fatal(err)
	}
	if created.OutlineID == "" || created.OutlineVersion != 1 || created.Status != OutlineStatusDraft || created.Title != "排序算法" {
		t.Fatalf("unexpected seeded outline: %+v", created)
	}
	if len(created.Nodes) != len(seed) || created.Nodes[0].NodeID != seed[0].NodeID || created.Nodes[1].Title != seed[1].Title {
		t.Fatalf("version nodes were not reused: %+v", created.Nodes)
	}
}

func TestOutlineEngineTimeoutBudget(t *testing.T) {
	if outlineRequestTimeout != 180*time.Second {
		t.Fatalf("outline engine timeout = %s, want 180s", outlineRequestTimeout)
	}
}

// TestGetOutlineVersionNotFound —— 读不存在的大纲 → ErrOutlineNotFound。
func TestGetOutlineVersionNotFound(t *testing.T) {
	svc := newTestService()
	_, err := svc.GetOutline(context.Background(), "outline_nope", 0)
	if !errors.Is(err, ErrOutlineNotFound) {
		t.Fatalf("不存在大纲应返回 ErrOutlineNotFound, 实际 %v", err)
	}
}

// TestCreateOutlineEngineStyleNodes —— 回归（4840ee5 引入的 422 缺陷）：
// Python /gen/outline 返回的引擎风格节点（node_type=slide、无 estimated_duration_minutes）
// 必须能创建为草稿；此前草稿校验误用确认严格校验导致必然 422，阻断整条大纲链路。
// 空占位节点（title/summary/key_points 全空）会被归一阶段滤除。
func TestCreateOutlineEngineStyleNodes(t *testing.T) {
	svc := newTestService()
	svc.aiClient = &fakeOutlineAI{generateResp: &OutlineGenerateResponse{Nodes: []OutlineNode{
		{NodeID: "node_001", NodeType: "slide", Title: "", Summary: ""}, // 空占位 → 应被滤除
		{NodeID: "node_002", NodeType: "slide", Title: "排序", Summary: "讲解"},
	}}}
	outline, err := svc.CreateOutline(context.Background(), OutlineGenerateRequest{SessionID: "s1"})
	if err != nil {
		t.Fatalf("引擎风格节点应能创建草稿, 实际 %v", err)
	}
	if outline.OutlineVersion != 1 || outline.Status != OutlineStatusDraft {
		t.Fatalf("应创建 v1 draft, 实际 v%d/%s", outline.OutlineVersion, outline.Status)
	}
	// 空占位节点被滤除，只剩有内容的节点
	if len(outline.Nodes) != 1 {
		t.Fatalf("空占位节点应被滤除, 期望剩 1 个, 实际 %d", len(outline.Nodes))
	}
	if outline.Nodes[0].NodeType != "slide" {
		t.Fatalf("slide 枚举应保留, 实际 %s", outline.Nodes[0].NodeType)
	}
	if outline.Nodes[0].EstimatedDurationMin <= 0 {
		t.Fatalf("时长应补默认值, 实际 %v", outline.Nodes[0].EstimatedDurationMin)
	}
}

// TestConfirmRejectsIncompleteNode —— 草稿宽松但确认仍严格：
// 标题空 / 时长缺失的节点不允许确认（规范 §3.5）。
func TestConfirmRejectsIncompleteNode(t *testing.T) {
	svc := newTestService()
	svc.aiClient = &fakeOutlineAI{generateResp: &OutlineGenerateResponse{Nodes: []OutlineNode{
		{NodeID: "node_001", NodeType: "slide", Title: "", Summary: ""}, // 标题空
	}}}
	outline, err := svc.CreateOutline(context.Background(), OutlineGenerateRequest{SessionID: "s1"})
	if err != nil {
		t.Fatalf("创建草稿应成功: %v", err)
	}
	if _, err := svc.ConfirmOutline(context.Background(), outline.OutlineID, 1); !errors.Is(err, ErrInvalidOutline) {
		t.Fatalf("标题空节点确认应被拒(ErrInvalidOutline), 实际 %v", err)
	}
}

// TestSaveDraftWithPlaceholderNode —— 手动新增的空占位节点保存时被滤除，
// 有内容的节点正常保存（修复"手动添加节点传不出去"+ 避免空节点阻塞确认）。
func TestSaveDraftWithPlaceholderNode(t *testing.T) {
	svc := newTestService()
	outline := mustCreateOutline(t, svc, "session_1")
	// 模拟前端手动新增一个未填内容的空占位节点
	nodes := sampleNodes()
	nodes = append(nodes, OutlineNode{NodeID: "node_new", Order: 3, NodeType: "content"})
	saved, err := svc.SaveOutlineVersion(context.Background(), outline.OutlineID, 1, nodes)
	if err != nil {
		t.Fatalf("含空占位节点的草稿保存应成功, 实际 %v", err)
	}
	if len(saved.Nodes) != 2 {
		t.Fatalf("空占位节点应被滤除, 期望剩 2 个, 实际 %d", len(saved.Nodes))
	}
}

// TestSaveDraftWithFilledNewNode —— 手动新增的已填节点正常保存并传递。
func TestSaveDraftWithFilledNewNode(t *testing.T) {
	svc := newTestService()
	outline := mustCreateOutline(t, svc, "session_1")
	nodes := sampleNodes()
	nodes = append(nodes, OutlineNode{
		NodeID: "node_new", Order: 3, Title: "课堂练习", Summary: "巩固", NodeType: "quiz",
		KeyPoints: []string{"练习"}, EstimatedDurationMin: 8,
	})
	saved, err := svc.SaveOutlineVersion(context.Background(), outline.OutlineID, 1, nodes)
	if err != nil {
		t.Fatalf("含已填新节点的草稿保存应成功, 实际 %v", err)
	}
	if len(saved.Nodes) != 3 {
		t.Fatalf("应保存 3 个节点, 实际 %d", len(saved.Nodes))
	}
	if saved.Nodes[2].NodeID != "node_new" || saved.Nodes[2].NodeType != "quiz" {
		t.Fatalf("新节点应完整保留, 实际 %+v", saved.Nodes[2])
	}
}
