package handler

import (
	"context"
	"errors"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"

	"smart-teaching-backend/internal/service"
)

// GenerationHandler S3 课件生成 — HTTP 处理器
type GenerationHandler struct {
	aiClient       service.AIEngine
	outlineService *service.OutlineService
	projectService *service.CoursewareProjectService
	coursewareSvc  *service.CoursewareService // 可选；用于落 modify 结果（契约 v1.0 §1.1）
}

// NewGenerationHandler 构造 S3 处理器。
// 后两个参数（CoursewareProjectService / CoursewareService）是可选的，
// 用于落库；旧调用方不传也能编译通过，只是失去落库能力。
func NewGenerationHandler(aiClient service.AIEngine, outlineService *service.OutlineService, projectServices ...interface{}) *GenerationHandler {
	h := &GenerationHandler{aiClient: aiClient, outlineService: outlineService}
	for _, c := range projectServices {
		switch v := c.(type) {
		case *service.CoursewareProjectService:
			if v != nil {
				h.projectService = v
			}
		case *service.CoursewareService:
			if v != nil {
				h.coursewareSvc = v
			}
		}
	}
	return h
}

// Create  POST /api/v1/gen/create — 创建生成任务
func (h *GenerationHandler) Create(c *gin.Context) {
	var req service.GenerationCreateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"code": 400, "message": "参数错误: " + err.Error()})
		return
	}
	if req.ProjectID != "" && h.projectService != nil && c.GetString("userID") == "" {
		c.JSON(http.StatusUnauthorized, gin.H{"code": 401, "message": "缺少用户身份"})
		return
	}
	if req.OutlineID != "" {
		if !req.OutlineConfirmed || req.OutlineVersion <= 0 || h.outlineService == nil {
			c.JSON(http.StatusConflict, gin.H{"code": 409, "message": "必须使用后端已确认的大纲版本生成课件"})
			return
		}
		outline, err := h.outlineService.GetConfirmed(c.Request.Context(), req.OutlineID, req.OutlineVersion)
		if err != nil {
			status := http.StatusConflict
			if errors.Is(err, service.ErrOutlineNotFound) {
				status = http.StatusNotFound
			}
			c.JSON(status, gin.H{"code": status, "message": err.Error()})
			return
		}
		req.OutlineNodes = outline.Nodes
	} else if req.OutlineConfirmed {
		c.JSON(http.StatusBadRequest, gin.H{"code": 400, "message": "outline_confirmed 需要 outline_id"})
		return
	}
	resp, err := h.aiClient.GenerationCreate(c.Request.Context(), req)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "message": "创建生成任务失败: " + err.Error()})
		return
	}
	if req.ProjectID != "" && h.projectService != nil {
		ownerID := c.GetString("userID")
		if err := h.projectService.AttachGeneration(c.Request.Context(), ownerID, req.ProjectID, resp.GenerationID); err != nil {
			if errors.Is(err, service.ErrCoursewareProjectNotFound) {
				c.JSON(http.StatusNotFound, gin.H{"code": 404, "message": "课件项目不存在"})
				return
			}
			if errors.Is(err, service.ErrCoursewareProjectArchived) {
				c.JSON(http.StatusConflict, gin.H{"code": 409, "message": "课件项目已归档"})
				return
			}
			c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "message": "关联课件项目失败"})
			return
		}
	}
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": resp})
}

// Status  GET /api/v1/gen/status/:task_id — 查询生成状态
func (h *GenerationHandler) Status(c *gin.Context) {
	taskID := c.Param("task_id")
	if taskID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"code": 400, "message": "缺少 task_id"})
		return
	}
	resp, err := h.aiClient.GenerationStatus(c.Request.Context(), taskID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "message": "查询生成状态失败: " + err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": resp})
}

// PreviewHTML POST /api/v1/gen/preview — 将生成节点渲染为可嵌入的 HTML 预览。
func (h *GenerationHandler) PreviewHTML(c *gin.Context) {
	var req service.GenerationPreviewRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"code": 400, "message": "参数错误: " + err.Error()})
		return
	}
	if len(req.Nodes) == 0 && req.GenID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"code": 400, "message": "nodes 或 gen_id 至少提供一个"})
		return
	}
	previewClient, ok := h.aiClient.(interface {
		GenerationPreview(context.Context, service.GenerationPreviewRequest) (*service.GenerationPreviewResponse, error)
	})
	if !ok {
		c.JSON(http.StatusNotImplemented, gin.H{"code": 501, "message": "当前 AI 客户端不支持 S3 HTML 预览"})
		return
	}
	resp, err := previewClient.GenerationPreview(c.Request.Context(), req)
	if err != nil {
		c.JSON(http.StatusBadGateway, gin.H{"code": 502, "message": "生成预览失败: " + err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": resp})
}

// Modify  POST /api/v1/gen/modify — 应用编辑命令，生成新版本快照
//
// 契约 v1.0 模块1 接口3：请求体可带 page_id + evidence_refs，把局部修改的证据
// 限定在该页绑定的 chunk 内；不传时保持现有行为（全库检索），向后兼容。
//
// 落库策略：调用 AI Engine 后，如果能根据 generation_id 反查到 project，
// 会通过 coursewareSvc.RecordModifyResult 把（请求 + 响应）作为 CoursewareVersion
// 快照写入 PostgreSQL，同时把用户提交的 evidence_refs 回写到 page_bindings。
// 这让"切 PPT 不重置 AI 对话"和"左侧绑定不可见"两类前端问题有一个权威读源。
// 落库失败不回滚 AI 响应（fire-and-record），保证前端流程不被后端 DB 抖动打断。
func (h *GenerationHandler) Modify(c *gin.Context) {
	var req service.GenerationModifyRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"code": 400, "message": "参数错误: " + err.Error()})
		return
	}
	resp, err := h.aiClient.GenerationModify(c.Request.Context(), req)
	if err != nil {
		if httpErr, isHTTP := err.(*service.AIEngineHTTPError); isHTTP {
			status := http.StatusBadGateway // 契约错误码：502 = AI引擎调用失败
			if httpErr.StatusCode == http.StatusNotFound {
				status = http.StatusNotFound // 契约错误码：404 = 版本/资源不存在
			}
			c.JSON(status, gin.H{"code": status, "message": "修改命令执行失败: " + httpErr.Error()})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "message": "修改命令执行失败: " + err.Error()})
		return
	}

	// 落库（仅在能反查到 project 时进行；找不到则保持纯代理语义，向后兼容）。
	if h.coursewareSvc != nil && req.GenerationID != "" {
		if proj, lookupErr := h.coursewareSvc.LookupProjectByGenID(c.Request.Context(), req.GenerationID); lookupErr == nil && proj != nil {
			h.coursewareSvc.RecordModifyResult(c.Request.Context(), proj.ProjectID, req, *resp)
		}
	}

	c.JSON(http.StatusOK, gin.H{"code": 200, "data": resp})
}

// Preview  GET /api/v1/gen/preview/:gen_id — 读取版本快照并渲染预览 HTML（前端刷新后恢复预览）。
func (h *GenerationHandler) Preview(c *gin.Context) {
	genID := c.Param("gen_id")
	if genID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"code": 400, "message": "缺少 gen_id"})
		return
	}
	var version *int
	if v := c.Query("version"); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			version = &n
		}
	}
	previewClient, ok := h.aiClient.(interface {
		GetPreview(context.Context, string, *int) (*service.GenerationPreviewResponse, error)
	})
	if !ok {
		c.JSON(http.StatusNotImplemented, gin.H{"code": 501, "message": "当前 AI 客户端不支持预览持久化"})
		return
	}
	resp, err := previewClient.GetPreview(c.Request.Context(), genID, version)
	if err != nil {
		if httpErr, isHTTP := err.(*service.AIEngineHTTPError); isHTTP && httpErr.StatusCode == http.StatusNotFound {
			c.JSON(http.StatusNotFound, gin.H{"code": 404, "message": "版本不存在，请先完成 S3 生成"})
			return
		}
		c.JSON(http.StatusBadGateway, gin.H{"code": 502, "message": "获取预览失败: " + err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": resp})
}

// Finalize POST /api/v1/gen/finalize — 从确认的内容节点创建版本快照（PPT 生成步骤）
func (h *GenerationHandler) Finalize(c *gin.Context) {
	var req service.GenerationFinalizeRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"code": 400, "message": "参数错误: " + err.Error()})
		return
	}
	if len(req.Nodes) == 0 {
		c.JSON(http.StatusBadRequest, gin.H{"code": 400, "message": "nodes 不能为空"})
		return
	}
	resp, err := h.aiClient.GenerationFinalize(c.Request.Context(), req)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "message": "生成终稿失败: " + err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": resp})
}
